/* -*- Mode: Java; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*-
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * Contributor(s):
 *   Rich Giuli <richard.giuli@sri.com>
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the NPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the NPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */
package test.liveconnect;

import java.util.Map;
import java.util.HashMap;

/**
 * LCTestClass is a simple class created and accessed from javascript during the
 * JRexLiveConnectSession unit tests.
 *
 * @see test.liveconnect.JRexLiveConnectSessionUnitTest
 */
public class LCTestClass {
    private String test_string;
    private int test_int;
    private float test_float;
    private double test_double;
    private long test_long;
    private Map testData = new HashMap();

    static void debug(String msg) {
        System.out.print("LCTestClass::");
        System.out.println(msg);
    }

    public void setTestString(String test_string) {
        debug("TestClass.setTestString<" + test_string + ">");
        this.test_string = test_string;
    }

    public String getTestString() {
        debug("TestClass.getTestString<" + test_string + ">");
        return test_string;
    }

    public void setTestInt(int test_int) {
        debug("TestClass.setTestInt<" + test_int + ">");
        this.test_int = test_int;
    }

    public int getTestInt() {
        debug("TestClass.getTestInt<" + test_int + ">");
        return test_int;
    }

    public void setTestFloat(float test_float) {
        debug("TestClass.setTestFloat<" + test_float + ">");
        this.test_float = test_float;
    }

    public float getTestFloat() {
        debug("TestClass.getTestFloat<" + test_float + ">");
        return test_float;
    }

    public void setTestDouble(double test_double) {
        debug("TestClass.setTestDouble<" + test_double + ">");
        this.test_double = test_double;
    }

    public double getTestDouble() {
        debug("TestClass.getTestDouble<" + test_double + ">");
        return test_double;
    }

    public void setTestLong(long test_long) {
        debug("TestClass.setTestLong<" + test_long + ">");
        this.test_long = test_long;
    }

    public long getTestLong() {
        debug("TestClass.setTestLong<" + test_long + ">");
        return test_long;
    }

    public Map getTestDataMap() {
        debug("TestClass.getTestDataMap");
        return testData;
    }
}
