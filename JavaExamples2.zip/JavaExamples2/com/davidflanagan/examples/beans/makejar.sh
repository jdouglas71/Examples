jar cmf manifest.stub YesNoPanelBean.jar -C ../../../../ com/davidflanagan/examples/beans/
